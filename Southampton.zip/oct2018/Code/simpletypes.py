# simple data types

a = 5
b = 4.3
c = "hello"
d = a + b
print (a,b,c)
print (type(a), type(b), type(c), type(d))

if type(b) is int :
    print (b, "is of type integer")
