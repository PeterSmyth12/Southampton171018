# This is a comment at the beginning of the line
print ("Hello World")   # This is a comment after the code
