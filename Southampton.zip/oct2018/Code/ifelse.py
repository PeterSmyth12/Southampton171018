# If ... Else ... EndIf

a = 4
b = 5
print ("a is", a, "b is",b)

if a > b :
    print (a, " is greater than ", b)
else :
    print (a, " is NOT greater than ", b)


a = 5
b = 4
print ("a is", a, "b is",b)

if a > b :
    print (a, " is greater than ", b)
else :
    print (a, " is NOT greater than ", b)




