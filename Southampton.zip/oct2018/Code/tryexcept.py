# try... except
x = "WWW"
try:
    int_x = int(x)
    print(x + 1)
except:
    print(x, "is not an integer")

x = 42
try:
    int_x = int(x)
    print(x + 1)
except:
    print(x, "is not an integer")

