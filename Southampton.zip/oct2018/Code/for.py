# for loop

print ("\nExample 1\n")
for i in [1,2,3] :
    print (i)
    
print ("\nExample 2\n")
for name in ["Tom", "Dick", "Harry"] :
    print (name)

print ("\nExample 3\n")
for name in ["Tom", 42, 3.142] :
    print (name)

print ("\nExample 4\n")
for i in range(3) :
    print (i)

print ("\nExample 5\n")
for i in range(1,4) :
    print (i)

print ("\nExample 6\n")
for i in range(2, 11, 2) :
    print (i)

    
